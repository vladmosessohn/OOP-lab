package com.poo.labvisitor.task1.document;

public class UrlSegment extends TextSegment{
    private String description;

    public UrlSegment(String url, String description){
        super(url);
        this.description = description;
    }

    public String getDescription(){
        return description;
    }

    public String getUrl() {
        return super.getContent();
    }

    public void accept(DocumentVisitor v) {
        v.visit(this);
    }
}
