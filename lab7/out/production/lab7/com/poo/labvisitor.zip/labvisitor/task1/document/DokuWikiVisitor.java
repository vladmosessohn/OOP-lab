package com.poo.labvisitor.task1.document;

public class DokuWikiVisitor implements DocumentVisitor {
    StringBuilder stringBuilder;
    public DokuWikiVisitor() {
        stringBuilder = new StringBuilder();
    }

    @Override
    public void visit(ItalicTextSegment t) {
        stringBuilder.append("//" + t.getContent() + "//");
    }

    @Override
    public void visit(BoldTextSegment t) {
        stringBuilder.append("*" + t.getContent() + "*");
    }

    @Override
    public void visit(UrlSegment t) {
        stringBuilder.append("[" + t.getUrl() + "]");
    }

    @Override
    public void visit(PlainTextSegment t) {
        stringBuilder.append(t);
    }

    @Override
    public StringBuilder getDocument() {
        return stringBuilder;
    }
}
