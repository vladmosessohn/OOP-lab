package com.poo.labvisitor.task1.document;

public interface DocumentVisitor {
    public void visit(ItalicTextSegment t);
    public void visit(BoldTextSegment t);
    public void visit(UrlSegment t);
    public void visit(PlainTextSegment t);
    public StringBuilder getDocument();
}
