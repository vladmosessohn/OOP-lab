package com.poo.labvisitor.task1.document;

public class MarkdownVisitor implements DocumentVisitor {
    StringBuilder stringBuilder;
    public MarkdownVisitor(){
        stringBuilder = new StringBuilder();
    }
    @Override
    public void visit(ItalicTextSegment t) {
        stringBuilder.append("*" + t.getContent() + "*");
    }

    @Override
    public void visit(BoldTextSegment t) {
        stringBuilder.append("**" + t.getContent() + "**");
    }

    @Override
    public void visit(UrlSegment t) {

    }

    @Override
    public void visit(PlainTextSegment t) {

    }

    @Override
    public StringBuilder getDocument() {
        return stringBuilder;
    }
}
